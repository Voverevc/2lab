package com.farizma.truthdare;

public class TruthItem{

    private String mText;

    public TruthItem(String text) {
        mText = text;
    }

    public String getmText() {
        return mText;
    }

}