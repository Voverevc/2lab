package com.example.bookdepository.database;

public class BookDbSchema {
    public static final class BookTable{
        public static final String NAME="books";
        public static final class Cols{
            public static final String UUID="uuid";
            public	static	final	String	TITLE = "title";
            public	static	final	String	DATE = "date";
            public	static	final	String	READED = "readed";

        }
    }
}
